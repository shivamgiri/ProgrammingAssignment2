## This program makes use of two functions makeCacheMatrix and cacheSolve 
## which is used to find inverse of an invertible matrix 


## This function(makeCacheMatrix) makes use of <<- operator and is used to create a list.

makeCacheMatrix <- function(x = matrix()) {
  
  invrs<-NULL
  set<-function(y){
    y<<-x
    invrs<<-NULL
  }
  get<-function()x
  setinverse<-function(inverse) invrs<<-inverse
  getinverse<-function() invrs
  list(set=set, get=get,setinverse=setinverse,getinverse=getinverse)

}


## This function calculates inverse of above matrix by making use of solve.

cacheSolve <- function(x, ...) {
  invrs<-x$getinverse()
  if(!is.null(invrs)){
    print("Getting cached data")
    return(invrs)
  }
  mat<-x$get()
  invrs<-solve(mat, ...)
  x$setinverse(invrs)
  invrs
        ## Return a matrix that is the inverse of 'x'
}
